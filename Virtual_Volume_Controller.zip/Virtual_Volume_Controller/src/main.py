import math
import time
import sys

try:
    import cv2
    import mediapipe as mp
    import pyautogui
    from ctypes import POINTER, cast
    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
except Exception as exc:
    print("\nA required package could not be imported.")
    print("Run the project using the included run.bat / Python 3.11 environment.")
    print(f"Details: {exc}")
    input("Press Enter to exit...")
    sys.exit(1)

# ---------- Tuning ----------
CAMERA_INDEX = 0
VOLUME_MIN_DISTANCE = 25       # fingertip distance in pixels
VOLUME_MAX_DISTANCE = 190
VOLUME_UPDATE_INTERVAL = 0.045
SWIPE_DISTANCE = 0.18          # fraction of frame width
SWIPE_TIME_LIMIT = 0.55        # seconds
SWIPE_COOLDOWN = 1.0
HOLD_CONFIRM_FRAMES = 4
# ---------------------------

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.02

def get_volume_interface():
    """Return Windows' default audio endpoint volume interface."""
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    return cast(interface, POINTER(IAudioEndpointVolume))

def distance(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

def fingers_extended(hand):
    """Return extension flags for index, middle, ring, pinky, and thumb."""
    lm = hand.landmark
    # For the four fingers, compare tip and PIP y coordinates (image y grows down).
    index = lm[8].y < lm[6].y
    middle = lm[12].y < lm[10].y
    ring = lm[16].y < lm[14].y
    pinky = lm[20].y < lm[18].y
    # Thumb extension is estimated horizontally; works best with palm facing camera.
    thumb = abs(lm[4].x - lm[3].x) > 0.045
    return thumb, index, middle, ring, pinky

def is_open_palm(flags):
    return all(flags)

def is_index_only(flags):
    thumb, index, middle, ring, pinky = flags
    return index and not middle and not ring and not pinky and not thumb

def main():
    try:
        volume = get_volume_interface()
    except Exception as exc:
        print("Could not access Windows system volume.")
        print("Check that you are running Windows and try again.")
        print(f"Details: {exc}")
        input("Press Enter to exit...")
        return

    cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap.release()
        cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        print("Could not open webcam. Close other webcam apps and check Windows Camera permissions.")
        input("Press Enter to exit...")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    mp_hands = mp.solutions.hands
    drawing = mp.solutions.drawing_utils
    hands = mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        model_complexity=0,
        min_detection_confidence=0.65,
        min_tracking_confidence=0.60,
    )

    hold_count = 0
    hold_active = False
    last_volume_update = 0.0
    swipe_origin_x = None
    swipe_origin_time = 0.0
    last_swipe_time = 0.0
    previous_index_mode = False
    status = "Show your hand"
    current_volume = int(round(volume.GetMasterVolumeLevelScalar() * 100))

    print("Virtual Volume Controller started. Click the browser you want to control.")
    print("Press Q in the webcam window to quit.")

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                status = "Webcam frame unavailable"
                time.sleep(0.05)
                continue

            frame = cv2.flip(frame, 1)
            height, width = frame.shape[:2]
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = hands.process(rgb)
            now = time.time()
            status = "No hand detected"

            if result.multi_hand_landmarks:
                hand = result.multi_hand_landmarks[0]
                drawing.draw_landmarks(frame, hand, mp_hands.HAND_CONNECTIONS)
                lm = hand.landmark

                def pt(i):
                    return (int(lm[i].x * width), int(lm[i].y * height))

                flags = fingers_extended(hand)
                palm = is_open_palm(flags)
                hold_count = min(HOLD_CONFIRM_FRAMES, hold_count + 1) if palm else max(0, hold_count - 1)
                if hold_count >= HOLD_CONFIRM_FRAMES:
                    hold_active = True
                elif hold_count == 0:
                    hold_active = False

                if hold_active:
                    status = "HOLD - gestures paused"
                    swipe_origin_x = None
                    previous_index_mode = False
                else:
                    thumb_tip = pt(4)
                    index_tip = pt(8)
                    pinch_distance = distance(thumb_tip, index_tip)

                    # Pinch gesture controls the Windows master volume.
                    if pinch_distance < VOLUME_MAX_DISTANCE and not is_index_only(flags):
                        ratio = (pinch_distance - VOLUME_MIN_DISTANCE) / (
                            VOLUME_MAX_DISTANCE - VOLUME_MIN_DISTANCE
                        )
                        ratio = max(0.0, min(1.0, ratio))
                        if now - last_volume_update >= VOLUME_UPDATE_INTERVAL:
                            try:
                                volume.SetMasterVolumeLevelScalar(float(ratio), None)
                                current_volume = int(round(ratio * 100))
                                last_volume_update = now
                            except Exception:
                                pass
                        cv2.line(frame, thumb_tip, index_tip, (0, 255, 255), 3)
                        cv2.circle(frame, index_tip, 8, (0, 255, 255), -1)
                        status = f"Volume control: {current_volume}%"

                    # Index-only horizontal swipe switches tabs in the focused app.
                    if is_index_only(flags):
                        center_x = float(lm[9].x)
                        if not previous_index_mode or swipe_origin_x is None:
                            swipe_origin_x = center_x
                            swipe_origin_time = now
                        else:
                            elapsed = now - swipe_origin_time
                            delta = center_x - swipe_origin_x
                            if elapsed <= SWIPE_TIME_LIMIT and abs(delta) >= SWIPE_DISTANCE:
                                if now - last_swipe_time >= SWIPE_COOLDOWN:
                                    try:
                                        if delta < 0:
                                            pyautogui.hotkey("ctrl", "shift", "tab")
                                            status = "Previous tab (swipe right to left)"
                                        else:
                                            pyautogui.hotkey("ctrl", "tab")
                                            status = "Next tab (swipe left to right)"
                                        last_swipe_time = now
                                    except Exception as exc:
                                        status = f"Keyboard shortcut failed: {exc}"
                                swipe_origin_x = center_x
                                swipe_origin_time = now
                            elif elapsed > SWIPE_TIME_LIMIT:
                                swipe_origin_x = center_x
                                swipe_origin_time = now
                        previous_index_mode = True
                    else:
                        swipe_origin_x = None
                        previous_index_mode = False
                        if status == "No hand detected":
                            status = "Pinch for volume | Open palm = HOLD"

                cv2.putText(frame, f"Volume: {current_volume}%", (20, 38),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

            cv2.rectangle(frame, (10, height - 88), (width - 10, height - 12), (20, 20, 20), -1)
            cv2.putText(frame, status[:90], (22, height - 52),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 120), 2)
            cv2.putText(frame, "Pinch: volume | Open palm: HOLD | Index swipe: tabs | Q: quit",
                        (22, height - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 255), 1)
            cv2.imshow("Virtual Volume Controller", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q") or key == ord("Q"):
                break
    finally:
        hands.close()
        cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
