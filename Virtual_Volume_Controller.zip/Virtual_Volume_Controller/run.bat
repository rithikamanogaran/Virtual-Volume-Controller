@echo off
cd /d "%~dp0"
py -3.11 -m venv .venv
if not exist ".venv\Scripts\python.exe" (
  echo Could not create the virtual environment. Install Python 3.11 64-bit first.
  pause
  exit /b 1
)
call .venv\Scripts\python.exe -m pip install --upgrade pip
call .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Installation failed. Check that Python 3.11 64-bit is installed and internet is available.
  pause
  exit /b 1
)
call .venv\Scripts\python.exe src\main.py
pause
