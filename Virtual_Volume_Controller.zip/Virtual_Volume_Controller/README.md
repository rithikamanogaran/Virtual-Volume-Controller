# Virtual Volume Controller — Windows

Control system volume and browser tabs with your webcam using Python, OpenCV, MediaPipe, Pycaw, and PyAutoGUI.

## Recommended setup
- Windows 10/11
- Python **3.11 64-bit**
- A working webcam
- Internet for the first dependency installation

## Run it
1. Extract this ZIP to a normal folder.
2. Install Python 3.11 64-bit from python.org. During installation, enable **Add Python to PATH**.
3. Double-click `run.bat`. The first run installs dependencies and may take a few minutes.
4. Allow webcam access if Windows asks.
5. Keep the controller window open. Press **Q** in the camera window to quit.

If you already use VS Code: open the extracted folder, open Terminal, and run:
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe src\main.py
```

## Gestures
- **Volume up/down:** bring thumb and index fingertip together, then move them apart/together. The distance controls volume.
- **HOLD / pause:** show an open palm with all five fingers extended. While HOLD is active, volume and tab gestures are ignored.
- **Switch browser tabs left/right:** extend **only your index finger** and swipe your hand:
  - swipe **right → left** = previous tab (`Ctrl+Shift+Tab`)
  - swipe **left → right** = next tab (`Ctrl+Tab`)
- **Quit:** press `Q` while the camera window is selected.

## Switching between Chrome windows/apps
Tab gestures switch tabs in the currently focused application. To switch between separate Chrome windows or different applications, first focus the desired app normally; this project does not guess which window you mean. The optional `Alt+Tab` behavior is not enabled to avoid accidentally leaving the browser.

## Important notes
- Gesture control sends keyboard shortcuts to the currently focused application. Click Chrome once before using tab swipes.
- Keep your hand fully visible and use good lighting.
- If another app is using the webcam, close it first.
- Windows system volume control uses Pycaw. This project is intended for Windows, not macOS/Linux.
- No software can guarantee error-free operation on every PC: webcam drivers, Python installations, permissions, and package availability differ. The launcher prints any installation/runtime error so it can be diagnosed.
